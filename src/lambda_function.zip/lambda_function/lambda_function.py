import sys
import logging
import pymysql
import json

# rds settings
rds_host  = ""
user_name = ""
password = ""
db_name = ""
db_table = ""

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")

def lambda_handler(event, context):
    """
    This function creates a new RDS database table and writes records to it
    """
    data = json.loads(event)
    name = data['id']
    temperature = data['TemperatureC']
    humidity = data['HumidityPercent']
    pressure = data['PressureHpa']
    gas = data['GasOhms']
    lVoltage = data['LightSensorVoltage']
    lRatio = data['LightSensorPercent']
    latency = data['latency']
    ts = data['dbts']
    ts = ts // 1000 # convert field to seconds from milliseconds
    
    sql_string = f"insert into {db_table} (name, temperature, humidity, pressure, gas, lVoltage, lRatio, latency) values('{name}', {temperature}, {humidity}, {pressure}, {gas}, {lVoltage}, {lRatio}, {latency})"

    with conn.cursor() as cur:
        cur.execute(sql_string)
        conn.commit()
    conn.commit()

    return f"Added message from {name} at timestamp: {ts}"
    